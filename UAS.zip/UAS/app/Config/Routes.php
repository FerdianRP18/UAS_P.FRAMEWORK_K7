<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index', ['as' => 'home']);
$routes->get('/pencarian', 'Pencarian::index');
$routes->get('/pesan', 'TiketSaya::index');
$routes->get('/login', 'Login::index', ['as' => 'login']);
$routes->get('/signin', 'Signin::index', ['as' => 'signin']);
$routes->get('/admin', 'Admin::index');

// batas percobaan
$routes->get('/produk', 'produk::index');
$routes->get('/mobil', 'mobil::index');
$routes->get('/bis', 'bis::index');
// $routes->get('/produk/(:any)/(:num)', 'produk::detail/$1/$2', ['as' => 'detailproduk']);
// $routes->get('/produk/(:alpha)', 'produk::nama_bus/$1');
// $routes->get('/produk/(:alpha)/(:num)', 'produk::no_bus/$1/$2');
// $routes->get('/produk/(:alpha)/(:num)/(:alphanum)', 'produk::plat/$1/$2/$3');
