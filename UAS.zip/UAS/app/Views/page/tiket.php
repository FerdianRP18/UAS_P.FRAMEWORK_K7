<?= $this->extend('template/index'); ?>
<?= $this->section('konten'); ?>

<!-- login -->
<div class="container">
    <section class="page-section h-75">
        <div class="card">
            <div class="card-body">
            </div>
        </div>
        <div class="card text-end" style="width: rem;">
            <div class="card-body">


                <h5 class="card-title">AKAS AAA <br><br>Patas AC2+2<br /><br>Uang Bisa Dikemblikan
                </h5>


                </p>
                <a href="#" class="btn btn-primary">PESAN SEKARANG</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
            </div>
        </div>
        <div class="card text-end" style="width: rem;">
            <div class="card-header">
                <h5 class="card-title">Special title treatment</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="btn btn-primary">PESAN SEKARANG</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
            </div>
        </div>
        <div class="card text-end" style="width: rem;">
            <div class="card-header">
                <h5 class="card-title">Special title treatment</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="btn btn-primary">PESAN SEKARANG</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
            </div>
        </div>
        <div class="card text-end" style="width: rem;">
            <div class="card-header">
                <h5 class="card-title">Special title treatment</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="btn btn-primary">PESAN SEKARANG</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
            </div>
        </div>
        <div class="card text-end" style="width: rem;">
            <div class="card-header">
                <h5 class="card-title">Special title treatment</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="btn btn-primary">PESAN SEKARANG</a>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection(); ?>