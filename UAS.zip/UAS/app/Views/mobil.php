<?= $this->extend('layout/template'); ?>
<?= $this->section('konten'); ?>
<div class="container">
    <h1>Koleksi Mobil</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores quis perferendis voluptates eum expedita! Sunt sit doloribus molestias labore eos? Quos optio minima tenetur asperiores, ab quisquam. Sint, iste sed?</p>
</div>
<?= $this->endSection(); ?>