<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
       
        $data = [
                'title' => 'Daftar Bis | PO SUMBER JAYA'
        ];
        
        return view('page/beranda', $data);
    }
}
