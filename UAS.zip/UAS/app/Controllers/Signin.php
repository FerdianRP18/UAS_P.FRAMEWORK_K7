<?php

namespace App\Controllers;

class Signin extends BaseController
{
    public function index()
    {
       
        $data = [
                'title' => 'Sign in | PO SUMBER JAYA'
        ];
        
        return view('page/signin', $data);
    }
}
