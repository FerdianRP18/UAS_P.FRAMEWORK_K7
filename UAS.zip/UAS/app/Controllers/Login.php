<?php

namespace App\Controllers;

class Login extends BaseController
{
    public function index()
    {
       
        $data = [
                'title' => 'Login | PO SUMBER JAYA'
        ];
        
        return view('page/login', $data);
    }
}
