<?php

namespace App\Controllers;

class TiketSaya extends BaseController
{
    public function index()
    {
       
        $data = [
                'title' => 'Tiket Saya | PO SUMBER JAYA'
        ];
        
        return view('page/tiket', $data);
    }
}
